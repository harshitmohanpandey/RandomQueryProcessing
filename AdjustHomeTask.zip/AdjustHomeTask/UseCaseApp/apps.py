from django.apps import AppConfig


class UsecaseappConfig(AppConfig):
    name = 'UseCaseApp'
